self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "412ee6f27f64b499520f2ee95c17deff",
    "url": "/index.html"
  },
  {
    "revision": "6a0c2746dc08bf3ddcf7",
    "url": "/static/css/main.60f9e1d7.chunk.css"
  },
  {
    "revision": "6f31ab0b8652be3a3392",
    "url": "/static/js/2.eb6eefbe.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.eb6eefbe.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6a0c2746dc08bf3ddcf7",
    "url": "/static/js/main.0d3ba020.chunk.js"
  },
  {
    "revision": "ac7ed0d48c415b63d4e4",
    "url": "/static/js/runtime-main.15e0933c.js"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);