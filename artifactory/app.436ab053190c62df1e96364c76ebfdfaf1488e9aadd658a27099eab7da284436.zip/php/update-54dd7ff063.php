<?php
/*
 * 功能：读取markdown文件
 *
 * Version: V5.0
 * By:yoby
 * date: 2018/8/28 12:41
 *
*/
$str = file_get_contents("../README-de0e9376b3.md");
exit($str);
